import React, { Component } from "react";

// App is class-component
class App extends Component {
  state = {
    employeeData:["Joseph", "QL" , "LY"]
  }

  //lifecycle 
  render() {
    return (
      //jsx
      // this refering to App
      <div>
        {this.state.employeeData.map((info) => {
          return (
            <div>
              {info}
            </div>
          )
        })}

      </div>
    )
  }

}

export default App;




// import React, { Component } from "react";

// // Create a object and update its data on click of a button and display data in UI
// class App extends Component {

//   state = {
//     language: "JavaScript",
//     typeoflanguage: "text-based programming language",
//     use1: "client-sidet",
//     use2: "server-side",
//     use3: "web pages",
//   };

//   handleClick = () => {
//     this.setState({
//       use1: "server-side",  
//       use2: "client-sidet",
//     });
//   };

//   render() {
//     return (
//       <div>
//         {this.state.language} is a {this.state.typeoflanguage} used 
//         both on the {this.state.use1} and {this.state.use2} that allows you to make {this.state.use3}. 
//         <button onClick={this.handleClick}>Update</button>
//       </div>
//     );
//   }
// }

// export default App;